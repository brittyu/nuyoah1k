<?php
namespace Allegro\Protobuf\Compiler;


class GenerationException extends \Exception {}